VELOCITY9X VGA HARDWARE SURVEY
Build: 8e4a5b63 (0.52.0)

WHAT THIS IS

Velocity9x is a display driver for Windows 98. It currently supports only a
couple of S3 chips. To support your card we need to know what is actually on
it, and this program collects that: the PCI identifiers, the video BIOS, the
video modes the card advertises, your monitor's EDID, and the VGA registers.

It reads. It does not change your video mode, does not install anything, and
does not leave anything behind on the card. The only file it creates is the
report.


HOW TO RUN IT

Best results come from real DOS, not a DOS window inside Windows.

   1. In Windows 98: Start, Shut Down, "Restart in MS-DOS mode".
      (Or boot from a DOS floppy. Or if the machine only runs DOS, you are
      already there.)
   2. Change to the folder holding V9XSURV.EXE.
   3. Type:  V9XSURV
   4. Answer the one question it asks (see below).
   5. Send back the file it names at the end - normally C:\V9XDIAG\V9XSURV.INI

Running it from a DOS box inside Windows does work and still produces a
useful file. It just cannot see as much.


THE QUESTION IT ASKS

Partway through it asks whether to run the vendor-specific probe. That step
writes the unlock keys published for your chipset family, reads the registers
behind them, and puts the originals back. It is where the video memory size,
the clock settings and the aperture layout come from, so please say yes if
you can.

Saying no is fine. The main report is already saved to disk before the
question is asked, so you lose only that last section.

If Windows is running, it will recommend saying no. Take its advice.


OPTIONS

   V9XSURV /rom        also dump the complete video BIOS image. Makes the
                       report several times larger, but is the best way to
                       identify an unusual card. Please use this if asked.
   V9XSURV /tier2      say yes to the question without being asked
   V9XSURV /notier2    say no to the question without being asked
   V9XSURV /aperture   read a few bytes from the card's linear memory
                       window, to find out whether the machine decodes
                       addresses there at all. Only asked for on ISA and
                       VESA Local Bus cards. See below.
   V9XSURV /out:A:\V9XDIAG\V9XSURV.INI    write the report somewhere else, for
                       example to a floppy on a machine with no spare disk
   V9XSURV /?          show this list


IF THE CARD IS ISA OR VESA LOCAL BUS

There is no PCI on those machines, so nothing can identify the card by
scanning the bus. Instead the vendor probe reads the chip's own identity
registers and continues only if they already say the card is an S3. Say yes
to the question, and please also put the markings on the card and its main
chip into a plain text file called V9XNOTE.TXT next to V9XSURV.EXE - that is
the one thing no register can tell us.

If we have asked for /aperture, run it like this:

   1. Reboot and press F5 when you see "Starting MS-DOS". That skips
      CONFIG.SYS and AUTOEXEC.BAT completely - no HIMEM, no EMM386, and no
      VESA/VBE TSR. The reading is only trustworthy without them.

      Use F5, not F8. F8 offers to run CONFIG.SYS line by line, and
      "Command prompt only" on some setups still runs it - we have measured a
      machine where it did, and the report showed EMM386 loaded.

   2. V9XSURV /aperture /rom /out:C:\V9XDIAG\V9XAPER.INI
   3. Send both reports - the ordinary one and this one.

Keep the reports separate and keep them all. If a later run locks the
machine up, the earlier reports are still on disk and still useful.

/aperture reads memory. It does not write to memory and does not write to
the card.


WHAT IS IN THE FILE

Plain text - open it in any editor and read it before you send it. It holds
hardware identifiers and register values only: no filenames, no serial
numbers from your machine, no personal information. It also records how much
memory is installed, which CPU is fitted, and whether HIMEM or EMM386 is
loaded, because on an older machine those decide where a card's memory
window can live. The one identifier that belongs to a physical object is
your monitor's EDID, which carries the monitor's model and its factory
serial number.


IF SOMETHING GOES WRONG

If the machine stops responding, power-cycle it. Nothing the survey does
survives a reboot. Then re-run with:

   V9XSURV /notier2

and send that report along with a note saying which card is fitted - the
basic report is still worth having, and knowing which card wedged the vendor
probe is itself useful.
